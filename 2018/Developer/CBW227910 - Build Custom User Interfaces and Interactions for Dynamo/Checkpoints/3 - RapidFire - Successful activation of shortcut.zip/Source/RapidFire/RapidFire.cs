﻿using Dynamo.Controls;
using Dynamo.ViewModels;
using Dynamo.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using static Dynamo.Models.DynamoModel;

namespace RapidFire
{
    public class RapidFire 
    {
        public HashSet<Shortcut> Shortcuts = new HashSet<Shortcut> { new Shortcut("DT", "Date Time") };
        public DynamoView View;

        public RapidFire(DynamoView view)
        {
            View = view;
        }

        private string GetNodeNameFromKeysEntered(string key)
        {
            Shortcut target = Shortcuts.FirstOrDefault(s => s.Keys.Equals(key.ToUpper()));
            return target?.NodeName;
        }

        static char? lastChar = null;
         
        public void View_KeyUp(object sender, KeyEventArgs e)
        {
            lastChar = null;
        }

        public void View_KeyDown(object sender, KeyEventArgs e)
        {
            if (lastChar == null)
            {
                char[] chars = e.Key.ToString().ToCharArray();
                if (chars.Length == 1)
                {
                    lastChar = chars[0];
                }
            }
            else
            {
                WorkspaceView wsV = View.ChildOfType<WorkspaceView>();
                WorkspaceViewModel wsVM = wsV.ViewModel as WorkspaceViewModel;
              
                var sel = wsVM.Model.CurrentSelection;
                var childrenNodeViews = View.ChildrenOfType<NodeView>();

                char[] chars = e.Key.ToString().ToCharArray();
                if (chars.Length == 1)
                {
                    string key = lastChar.ToString() + chars[0].ToString();

                    TryAndPlaceNode(key);
                    lastChar = null;
                }
            }
        }

        private void TryAndPlaceNode(string key)
        {
            string nodeName = GetNodeNameFromKeysEntered(key);
            if (nodeName != null)
            {
                DynamoViewModel vm = View.DataContext as DynamoViewModel;
                System.Windows.Point pnt;
                System.Windows.Point adjusted = new System.Windows.Point(0,0);
                try
                {
                    //todo playl with how to apply the scale and x/y values.  x/y kind works
                    WorkspaceView wsV = View.ChildOfType<WorkspaceView>();
                    pnt = Mouse.GetPosition(wsV);
                    double scale = wsV.ViewModel.Zoom;
                    double X = wsV.ViewModel.X;
                    double Y = wsV.ViewModel.Y;
                    adjusted = new System.Windows.Point( pnt.X / scale - X/scale, pnt.Y/scale - Y/scale);
                }
                catch (Exception)
                {
                    pnt = new System.Windows.Point(0,0);
                }
                try
                {
                    vm.Model.ExecuteCommand(new CreateNodeCommand(Guid.NewGuid().ToString(), nodeName, adjusted.X, adjusted.Y, false, false));
                }
                catch { }
            }
        }
    }
}
