﻿using Dynamo.Controls;
using Dynamo.ViewModels;
using Dynamo.Wpf.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace RapidFire
{
    public class ViewExtensionLoaded : IViewExtension
    {
        public string UniqueId => "C46362AA-B570-43FE-B684-B0EC45E816DC";

        public string Name => "Hello Dynamo";

        public void Loaded(ViewLoadedParams p)
        {
            MessageBox.Show("Hello there, viewExtension has loaded!");

            RapidFire rF = new RapidFire();

            Events.RegisterEventHandlers(p, rF);
        }

        public void Dispose() { }

        public void Shutdown()
        {
            Events.UnregisterEventHandlers();
        }

        public void Startup(ViewStartupParams p) { }
    }
}
