﻿using Dynamo.Controls;
using Dynamo.ViewModels;
using Dynamo.Wpf.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace RapidFire
{
    public class ViewExtensionLoaded : IViewExtension
    {
        public string UniqueId => "C46362AA-B570-43FE-B684-B0EC45E816DC";

        public string Name => "Hello Dynamo";

        public void Loaded(ViewLoadedParams p)
        {
            
            RapidFire rF = new RapidFire();
            MenuItem MI = new MenuItem();
            MI.Header = "Rapid Fire";
            MI.Click += (o, e) =>
            {
                MessageBox.Show("Hello there!");
            };
            p.AddMenuItem(MenuBarType.View, MI);

            Events.RegisterEventHandlers(p, rF);
        }

        public void Dispose() { }

        public void Shutdown()
        {
            Events.UnregisterEventHandlers();
        }

        public void Startup(ViewStartupParams p) { }
    }
}
