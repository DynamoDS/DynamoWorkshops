﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RapidFire
{
    public class Serialization
    {
        internal List<Shortcut> ReadFile(string filePath)
        {
            List<Shortcut> shortcuts = new List<Shortcut>();
            try
            {
                using (StreamReader stream = new StreamReader(filePath))
                {
                    while (!stream.EndOfStream)
                    {
                        string[] shortcutParts = stream.ReadLine().Split(new char[1] { '|' });
                        string nodeName = shortcutParts[1];
                        var thisCut = new Shortcut(shortcutParts[0].ToUpper(), shortcutParts[1]);

                        shortcuts.Add(thisCut);
                    }
                }
                return shortcuts;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        internal void WriteShortcutsToFile(string shortcutPath, List<Shortcut> shortcuts)
        {
            // First clear all the existing contents so we don't write duplicates
            File.WriteAllText(shortcutPath, string.Empty);

            // Then write all shortcuts with non-empty keys to the File
            using (StreamWriter shortcutsFile = new StreamWriter(shortcutPath))
            {
                foreach (Shortcut shortcut in shortcuts)
                {
                    if (!shortcut.Keys.Equals(""))
                    {
                        string shcut = shortcut.Keys.ToUpper() + "|" + shortcut.NodeName + "|";
                        shortcutsFile.WriteLine(shcut);
                    }
                }
            }
        }
    }
}
